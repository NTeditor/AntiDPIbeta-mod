su -c dpi stop
su -c dpi start