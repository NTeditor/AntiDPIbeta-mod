AUTOSTART="true"
if [ "$AUTOSTART" == "true" ]; then
su -c "/system/bin/dpi start"  
fi; 
