MODDIR=${0%/*}
source=$MODDIR/system/bin/dpi
rm $dpi_list_path/$dpi_ignore
rm $dpi_list_path/list-youtube.txt
rm $dpi_list_path/$dpi_list
fi